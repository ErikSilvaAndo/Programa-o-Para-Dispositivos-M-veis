import { Text, View, StyleSheet, ScrollView } from "react-native";
import Lista from './componentes/lista'

const fotos = [
  {
  id: 1,
  titulo: 'Curbelo',
  descricao: 'Um Gabriel Curbelo Pedra',
  imagem: require('../assets/images/curbelo.png')
  },
  {
  id: 2,
  titulo: 'Eu e o Gato',
  descricao: 'Eu e um gato na minha cabeça, no estilo do studio ghibli',
  imagem: require('../assets/images/euEGato.png')
  },
  {
  id: 3,
  titulo: 'Foto Amigos',
  descricao: 'Eu e alguns amigos da escola',
  imagem: require('../assets/images/foto amigos.png')
  },
  {
  id: 4,
  titulo: 'Raphael',
  descricao: 'Professor Raphael todo bonitinho arrumando o terno',
  imagem: require('../assets/images/Raphael.jpg')
  },
  {
  id: 5,
  titulo: 'Raphal, Eu e o Jhonathan',
  descricao: 'Eu, meu amigo e o professor',
  imagem: require('../assets/images/raphaelEuJhonathan.png')
  }
]

export default function Index() {
  return (
    <ScrollView>
    <View style={estilos.cabecalho}>
      <Text style={estilos.titulo}>Galeria de Fotos</Text>
      <View style={estilos.container}>
        <Text>
          <Lista fotos={fotos}></Lista>
        </Text>
      </View>
    </View>
    </ScrollView>
  );
}

const estilos = StyleSheet.create({
  container:{
    flex: 1,
    padding: 20,
    backgroundColor: '#aca0a0ff'
  },
  cabecalho:{
    width: '100%',
    height: 60,
    backgroundColor: '#f6f4f4ff',
    alignItems: 'center',
    justifyContent: 'center'
  },
  titulo:{
    fontSize: 29
  }
})